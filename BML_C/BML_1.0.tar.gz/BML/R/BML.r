creatBMLGrid=
  #
  #This function is a liitle bit different from previous ones. We use 3 to denote red car 
  #instead of 2.
  #
  function(r = 100, c = 99, ncars = c(blue = 100, red = 100), p = 0)
  {
    if(p != 0){
      blue = red = ceiling(r*c*p/2)
      ncars = c(blue, red)
    }
    if (p<0|p>0.9) stop("Density should be positive and not greater than 0.9")
    r = ceiling(r)
    c = ceiling(c)
    if(c<=0|r<=0) stop("Dimensions should be positive")
    
    
    grid = matrix(0,r,c)
    pos = sample(r*c, sum(ncars))
    
    grid[pos] = sample(rep(c(1,3),times = ncars))
    class(grid) = c("BMLGrid",class(grid))
    grid
  }

moveCar.c = 
    #  
    #we creat a new matrix based on the original one
    #calculate the difference each element to diecide which cars is to move.
    #
function(grid,time){
    if(time%%2 == 1){
      grid.new = rbind(grid[nrow(grid),], grid[1:(nrow(grid)-1),])
      
      findMov = which(grid.new - grid == -1 ) #This is the blue car which can move in this step.
      grid[findMov] = 0
      
      rule = (findMov - 1L)%%nrow(grid)
      findMov[rule==0] =  
        findMov[rule==0] + nrow(grid) - 1 
      findMov[rule != 0] = 
        findMov[rule != 0] - 1
      
      grid[findMov] = 1
    }
      else{
        grid.new = cbind(grid[,2:ncol(grid)],grid[,1])
      
        findMov = which(grid.new - grid == -3 )
        grid[findMov] = 0
        
        rule = findMov - (ncol(grid)-1)*nrow(grid)
        findMov[rule>0] =  
          findMov[rule>0] - (ncol(grid)-1)*nrow(grid)
        findMov[rule <= 0] = 
          findMov[rule <= 0] + nrow(grid)
        
        grid[findMov] = 3
  }
  grid
}

runBMLGrid = 
  function(grid, numSteps){
    if(any(!is.numeric(numSteps)) | length(numSteps) != 1 )  
      stop("numSteps need to be an positive integer")
    
    if(numSteps <= 0 | numSteps %% 1 != 0 )
      stop("numSteps need to be an positive integer")
    
    if(!"BMLGrid" %in% class(grid))
      stop("car need to be a BMLGrid object")
   
    for(i in 1:numSteps)
      grid = moveCar.c(grid,i)
    grid
  }


carVelocity = 
  function(grid,carType){
    if(carType == 1){
      grid.new = rbind(grid[nrow(grid),], grid[1:(nrow(grid)-1),])
      blueMov = length(which(grid.new - grid == -1 ))
      velocity = blueMov/length(which(grid==1))
    }
    else {
      grid.new = cbind(grid[,2:ncol(grid)],grid[,1])
      redMov = length(which(grid.new - grid == -3 ))
      velocity = redMov/length(which(grid==3))
    }
    velocity
  }

summary.BMLGrid = 
  #
  #how many cars(red?blue?)
  #how many cars are blocked
  function(object, ...){
    r = nrow(object)
    c = ncol(object)
    
    car.num = length(which(object != 0))
    blue.num = length(which(object == 1))
    red.num = length(which(object == 3))
    
    velocityBlue = round(carVelocity(object, 1), 3)
    velocityRed = round(carVelocity(object, 3), 3)
    
    notmovBlue = blue.num - velocityBlue*blue.num
    notmovRed = red.num - velocityBlue*red.num 
    
    
    cat(' This is a ',r,'*',c,'GRID:',
        '\n','There are total',car.num,'CARS:',
        '\n','                  BLUE               RED             ',
        '\n','NUM           ',blue.num,'               ',red.num,
        '\n','BLOCKED NUM   ',notmovBlue,'                ',notmovRed,
        '\n','VELOCITY      ',velocityBlue,'              ',velocityRed,'\n')
  }

plot.BMLGrid = 
  
  function(x, ...){
    x[x == 3] = 2
    image(t(x[nrow(x):1,]),col=c("white","blue","red"), 
          axes = FALSE, xlab = "", ylab = "")
    box()
  }

crunBMLGrid =
  function(grid, numStep){
    
    if(any(!is.numeric(numStep)) | length(numStep) != 1 )  
      stop("numSteps need to be an positive integer")
    
    if(numStep <= 0 | numStep %% 1 != 0 )
      stop("numSteps need to be an positive integer")
    
    if(!"BMLGrid" %in% class(grid))
      stop("car need to be a BMLGrid object")
    
    
    grid.vec = as.vector(grid)
    row = nrow(grid)
    col = nrow(grid)
    newgrid = .C("runBMLGrid", matrix = as.integer(grid.vec), row = as.integer(row),
                 col = as.integer(col), numStep = as.integer(numStep))$matrix
    newgrid = matrix(newgrid,nrow = row)
    class(newgrid) = c("BMLGrid",class(newgrid))
    newgrid
  }





