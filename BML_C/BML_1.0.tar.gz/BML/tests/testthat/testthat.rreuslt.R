library(BML)
context("test of runBMLGried function")

test_that("The grid should be same",
{
  cat('Running addition test...\n')
  grid_test = matrix(c(3,3,0,0,0,0,3,3,0,1,1,1,1,3,1,0),nrow = 4)
  grid_test_1 = matrix(c(3,3,0,0,0,0,3,3,1,0,1,1,0,3,1,1),nrow = 4)
  class(grid_test) = c("BMLGrid",class(grid_test))
  class(grid_test_1) = c("BMLGrid",class(grid_test_1))
  expect_equal(runBMLGrid(grid_test ,1), grid_test_1)
})
