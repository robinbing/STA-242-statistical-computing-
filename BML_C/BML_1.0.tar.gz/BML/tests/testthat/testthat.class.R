library(BML)
context("test the class of grid")

test_that("the grid's class",{
  g = creatBMLGrid(3,3,p=0.2)
  expect_is(g, "BMLGrid")
})