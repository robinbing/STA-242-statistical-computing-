library("BML")
context("BMLGrid create")

test_that("creatBMLGrid input",{
  expect_error(creatBMLGrid(3,3,p = -0.2), 
               "Density should be positive and not greater than 0.9")
  expect_error(creatBMLGrid(3,3,p = 1), 
               "Density should be positive and not greater than 0.9")
  expect_error(creatBMLGrid(-3,3,p = 0.3), 
               "Dimensions should be positive")
})