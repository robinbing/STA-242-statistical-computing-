library(testthat)
library(BML)

test_check("BML")
